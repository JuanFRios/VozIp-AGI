grant all privileges on biblioteca.* to 'usrbiblioteca'@'localhost' identified by 'passbiblioteca' with grant option;
flush privileges;
